{
name: "Alabama",
value: 4833722,
items: [{
    name: "Birmingham",
    value: 212113
    },
    {
    name: "Montgomery",
    value: 201332
    },
    {
    name: "Mobile",
    value: 194899
    },
    {
    name: "Huntsville",
    value: 186254
    },
    {
    name: "Tuscaloosa",
    value: 95334
    },
    {
    name: "Hoover",
    value: 84126
    },
    {
    name: "Dothan",
    value: 68001
    },
    {
    name: "Auburn",
    value: 58582
    },
    {
    name: "Decatur",
    value: 55816
    }]
},
{
name: "Alaska",
value: 735132,
items: [{
    name: "Anchorage",
    value: 300950
    },
    {
    name: "Badger",
    value: 20200
    },
    {
    name: "College",
    value: 13400
    },
    {
    name: "Fairbanks",
    value: 32324
    },
    {
    name: "Juneau",
    value: 32660
    },
    {
    name: "Ketchikan",
    value: 8214
    },
    {
    name: "Sitka",
    value: 9020
    }]
},
{
name: "Arizona",
value: 6626624,
items: [{
    name: "Phoenix",
    value: 1513367
    },
    {
    name: "Tucson",
    value: 526116
    },
    {
    name: "Mesa",
    value: 457587
    },
    {
    name: "Chandler",
    value: 249146
    },
    {
    name: "Glendale",
    value: 234632
    },
    {
    name: "Gilbert",
    value: 229972
    },
    {
    name: "Scottsdale",
    value: 226918
    },
    {
    name: "Tempe",
    value: 168228
    },
    {
    name: "Peoria",
    value: 162592
    },
    {
    name: "Surprise",
    value: 123546
    }]
},
{
name: "Arkansas",
value: 2959373,
items: [{
    name: "Little Rock",
    value: 197357
    },
    {
    name: "Fort Smith",
    value: 87650
    },
    {
    name: "Fayetteville",
    value: 78960
    },
    {
    name: "Springdale",
    value: 75229
    },
    {
    name: "Jonesboro",
    value: 71551
    },
    {
    name: "North Little Rock",
    value: 66075
    },
    {
    name: "Conway",
    value: 63816
    },
    {
    name: "Rogers",
    value: 60112
    },
    {
    name: "Pine Bluff",
    value: 46094
    },
    {
    name: "Bentonville",
    value: 40167
    }]
},
{
name: "California",
value: 38332521,
items: [{
    name: "Los Angeles",
    value: 3884307
    },
    {
    name: "San Diego",
    value: 1355896
    },
    {
    name: "San Jose",
    value: 998537
    },
    {
    name: "San Francisco",
    value: 837442
    },
    {
    name: "Fresno",
    value: 509924
    },
    {
    name: "Sacramento",
    value: 479686
    },
    {
    name: "Long Beach",
    value: 469428
    },
    {
    name: "Oakland",
    value: 406253
    },
    {
    name: "Bakersfield",
    value: 363630
    },
    {
    name: "Anaheim",
    value: 345012
    },
    {
    name: "Santa Ana",
    value: 334227
    }]
},
{
name: "Colorado",
value: 5268367,
items: [{
    name: "Denver",
    value: 649495
    },
    {
    name: "Colorado Springs",
    value: 439886
    },
    {
    name: "Aurora",
    value: 345803
    },
    {
    name: "Fort Collins",
    value: 152061
    },
    {
    name: "Lakewood",
    value: 147214
    },
    {
    name: "Thornton",
    value: 127359
    },
    {
    name: "Arvada",
    value: 111707
    },
    {
    name: "Westminster",
    value: 110945
    },
    {
    name: "Pueblo",
    value: 108249
    },
    {
    name: "Centennial",
    value: 106114
    },
    {
    name: "Boulder",
    value: 103166
    },
    {
    name: "Highlands Ranch",
    value: 102000
    }]
},
{
name: "Connecticut",
value: 3596080,
items: [{
    name: "Bridgeport",
    value: 147216
    },
    {
    name: "New Haven",
    value: 130660
    },
    {
    name: "Stamford",
    value: 126456
    },
    {
    name: "Hartford",
    value: 125017
    },
    {
    name: "Waterbury",
    value: 109676
    },
    {
    name: "Norwalk",
    value: 87776
    },
    {
    name: "Danbury",
    value: 83684
    },
    {
    name: "New Britain",
    value: 72939
    },
    {
    name: "West Hartford",
    value: 63371
    },
    {
    name: "Bristol",
    value: 60568
    },
    {
    name: "Meriden",
    value: 60456
    }]
},
{
name: "Delaware",
value: 925749,
items: [{
    name: "Bear",
    value: 19700
    },
    {
    name: "Dover",
    value: 37366
    },
    {
    name: "Middletown",
    value: 19600
    },
    {
    name: "Newark",
    value: 19600
    },
    {
    name: "Wilmington",
    value: 71525
    }]
},
{
name: "District of Columbia",
value: 646449,
items: [{
    name: "Washington",
    value: 646449
    }]
},
{
name: "Florida",
value: 19552860,
items: [{
    name: "Jacksonville",
    value: 842583
    },
    {
    name: "Miami",
    value: 417650
    },
    {
    name: "Tampa",
    value: 352957
    },
    {
    name: "Orlando",
    value: 255483
    },
    {
    name: "St. Petersburg",
    value: 249688
    },
    {
    name: "Hialeah",
    value: 233394
    },
    {
    name: "Tallahassee",
    value: 186411
    },
    {
    name: "Fort Lauderdale",
    value: 172389
    },
    {
    name: "Port St. Lucie",
    value: 171016
    },
    {
    name: "Cape Coral",
    value: 165831
    },
    {
    name: "Pembroke Pines",
    value: 162329
    }]
},
{
name: "Georgia",
value: 9992167,
items: [{
    name: "Atlanta",
    value: 447841
    },
    {
    name: "Columbus",
    value: 202824
    },
    {
    name: "Augusta",
    value: 197350
    },
    {
    name: "Savannah",
    value: 142772
    },
    {
    name: "Athens",
    value: 119980
    },
    {
    name: "Sandy Springs",
    value: 99770
    },
    {
    name: "Roswell",
    value: 94034
    },
    {
    name: "Macon",
    value: 89981
    },
    {
    name: "Johns Creek",
    value: 82788
    },
    {
    name: "Albany",
    value: 76185
    }]
},
{
name: "Hawaii",
value: 1404054,
items: [{
    name: "Honolulu (Urban Honolulu CDP)",
    value: 347884
    }]
},
{
name: "Idaho",
value: 1612136,
items: [{
    name: "Boise City",
    value: 214237
    },
    {
    name: "Nampa",
    value: 86518
    },
    {
    name: "Meridian",
    value: 83596
    },
    {
    name: "Idaho Falls",
    value: 58292
    },
    {
    name: "Pocatello",
    value: 54350
    },
    {
    name: "Caldwell",
    value: 48957
    },
    {
    name: "Coeur d'Alene",
    value: 46402
    },
    {
    name: "Twin Falls",
    value: 45981
    },
    {
    name: "Lewiston",
    value: 32401
    }]
},
{
name: "Illinois",
value: 12882135,
items: [{
    name: "Chicago",
    value: 2718782
    },
    {
    name: "Aurora",
    value: 199963
    },
    {
    name: "Rockford",
    value: 150251
    },
    {
    name: "Joliet",
    value: 147806
    },
    {
    name: "Naperville",
    value: 144864
    },
    {
    name: "Springfield",
    value: 117006
    },
    {
    name: "Peoria",
    value: 116513
    },
    {
    name: "Elgin",
    value: 110145
    },
    {
    name: "Waukegan",
    value: 88826
    },
    {
    name: "Cicero",
    value: 84103
    },
    {
    name: "Champaign",
    value: 83424
    }]
},
{
name: "Indiana",
value: 6570902,
items: [{
    name: "Indianapolis",
    value: 843393
    },
    {
    name: "Fort Wayne",
    value: 256496
    },
    {
    name: "Evansville",
    value: 120310
    },
    {
    name: "South Bend",
    value: 100886
    },
    {
    name: "Carmel",
    value: 85927
    },
    {
    name: "Fishers",
    value: 83891
    },
    {
    name: "Bloomington",
    value: 82575
    },
    {
    name: "Hammond",
    value: 78967
    },
    {
    name: "Gary",
    value: 78450
    },
    {
    name: "Lafayette",
    value: 70373
    },
    {
    name: "Muncie",
    value: 70316
    }]
},
{
name: "Iowa",
value: 3090416,
items: [{
    name: "Des Moines",
    value: 207510
    },
    {
    name: "Cedar Rapids",
    value: 128429
    },
    {
    name: "Davenport",
    value: 102157
    },
    {
    name: "Sioux City",
    value: 82459
    },
    {
    name: "Iowa City",
    value: 71591
    },
    {
    name: "Waterloo",
    value: 68366
    },
    {
    name: "Council Bluffs",
    value: 61969
    },
    {
    name: "Ames",
    value: 61792
    },
    {
    name: "West Des Moines",
    value: 61255
    },
    {
    name: "Dubuque",
    value: 58253
    },
    {
    name: "Ankeny",
    value: 51567
    }]
},
{
name: "Kansas",
value: 2893957,
items: [{
    name: "Wichita",
    value: 386552
    },
    {
    name: "Overland Park",
    value: 181260
    },
    {
    name: "Kansas City",
    value: 148483
    },
    {
    name: "Olathe",
    value: 131885
    },
    {
    name: "Topeka",
    value: 127679
    },
    {
    name: "Lawrence",
    value: 90811
    },
    {
    name: "Shawnee",
    value: 64323
    },
    {
    name: "Manhattan",
    value: 56143
    },
    {
    name: "Lenexa",
    value: 50344
    },
    {
    name: "Salina",
    value: 47846
    }]
},
{
name: "Kentucky",
value: 4395295,
items: [{
    name: "Louisville",
    value: 609893
    },
    {
    name: "Lexington",
    value: 308428
    },
    {
    name: "Bowling Green",
    value: 61488
    },
    {
    name: "Owensboro",
    value: 58416
    },
    {
    name: "Covington",
    value: 40956
    },
    {
    name: "Hopkinsville",
    value: 32582
    },
    {
    name: "Richmond",
    value: 32550
    },
    {
    name: "Florence",
    value: 31423
    },
    {
    name: "Georgetown",
    value: 30872
    },
    {
    name: "Elizabethtown",
    value: 29948
    }]
},
{
name: "Louisiana",
value: 4625470,
items: [{
    name: "New Orleans",
    value: 378715
    },
    {
    name: "Baton Rouge",
    value: 229426
    },
    {
    name: "Shreveport",
    value: 200327
    },
    {
    name: "Metairie",
    value: 139000
    },
    {
    name: "Lafayette",
    value: 124276
    },
    {
    name: "Lake Charles",
    value: 74024
    },
    {
    name: "Kenner",
    value: 66975
    },
    {
    name: "Bossier City",
    value: 66333
    },
    {
    name: "Monroe",
    value: 49761
    },
    {
    name: "Alexandria",
    value: 48426
    }]
},
{
name: "Maine",
value: 1328302,
items: [{
    name: "Portland",
    value: 66318
    },
    {
    name: "Lewiston",
    value: 36437
    },
    {
    name: "Bangor",
    value: 32673
    }]
},
{
name: "Maryland",
value: 5928814,
items: [{
    name: "Baltimore",
    value: 622104
    },
    {
    name: "Columbia",
    value: 105000
    }]
},
{
name: "Massachusetts",
value: 6692824,
items: [{
    name: "Boston",
    value: 645966
    },
    {
    name: "Worcester",
    value: 182544
    },
    {
    name: "Springfield",
    value: 153703
    },
    {
    name: "Lowell",
    value: 108861
    },
    {
    name: "Cambridge",
    value: 107289
    },
    {
    name: "New Bedford",
    value: 95078
    },
    {
    name: "Brockton",
    value: 94089
    },
    {
    name: "Quincy",
    value: 93494
    },
    {
    name: "Lynn",
    value: 91589
    },
    {
    name: "Fall River",
    value: 88697
    },
    {
    name: "Newton",
    value: 87971
    }]
},
{
name: "Michigan",
value: 9895622,
items: [{
    name: "Detroit",
    value: 688701
    },
    {
    name: "Grand Rapids",
    value: 192294
    },
    {
    name: "Warren",
    value: 134873
    },
    {
    name: "Sterling Heights",
    value: 131224
    },
    {
    name: "Ann Arbor",
    value: 117025
    },
    {
    name: "Lansing",
    value: 113972
    },
    {
    name: "Flint",
    value: 99763
    },
    {
    name: "Clinton",
    value: 98477
    },
    {
    name: "Dearborn",
    value: 95884
    },
    {
    name: "Livonia",
    value: 95208
    }]
},
{
name: "Minnesota",
value: 5420380,
items: [{
    name: "Minneapolis",
    value: 400070
    },
    {
    name: "St. Paul",
    value: 294873
    },
    {
    name: "Rochester",
    value: 110742
    },
    {
    name: "Bloomington",
    value: 86319
    },
    {
    name: "Duluth",
    value: 86128
    },
    {
    name: "Brooklyn Park",
    value: 78373
    },
    {
    name: "Plymouth",
    value: 73987
    },
    {
    name: "St. Cloud",
    value: 66297
    },
    {
    name: "Woodbury",
    value: 65656
    },
    {
    name: "Eagan",
    value: 65453
    },
    {
    name: "Maple Grove",
    value: 65415
    }]
},
{
name: "Mississippi",
value: 2991207,
items: [{
    name: "Jackson",
    value: 172638
    },
    {
    name: "Gulfport",
    value: 71012
    },
    {
    name: "Southaven",
    value: 50997
    },
    {
    name: "Hattiesburg",
    value: 47556
    },
    {
    name: "Biloxi",
    value: 44820
    },
    {
    name: "Meridian",
    value: 40921
    },
    {
    name: "Tupelo",
    value: 35827
    },
    {
    name: "Olive Branch",
    value: 34963
    },
    {
    name: "Greenville",
    value: 33203
    }]
},
{
name: "Missouri",
value: 6044171,
items: [{
    name: "Kansas City",
    value: 467007
    },
    {
    name: "St. Louis",
    value: 318416
    },
    {
    name: "Springfield",
    value: 164122
    },
    {
    name: "Independence",
    value: 117240
    },
    {
    name: "Columbia",
    value: 115276
    },
    {
    name: "Lee's Summit",
    value: 93184
    },
    {
    name: "O'Fallon",
    value: 82809
    },
    {
    name: "St. Joseph",
    value: 77147
    },
    {
    name: "St. Charles",
    value: 67569
    }]
},
{
name: "Montana",
value: 1015165,
items: [{
    name: "Billings",
    value: 109059
    },
    {
    name: "Bozeman",
    value: 39860
    },
    {
    name: "Butte-Silver Bow",
    value: 33854
    },
    {
    name: "Great Falls",
    value: 59351
    },
    {
    name: "Helena",
    value: 29596
    },
    {
    name: "Kalispell",
    value: 20972
    },
    {
    name: "Missoula",
    value: 69122
    }]
},
{
name: "Nebraska",
value: 1868516,
items: [{
    name: "Bellevue",
    value: 53663
    },
    {
    name: "Columbus",
    value: 22533
    },
    {
    name: "Fremont",
    value: 26340
    },
    {
    name: "Grand Island",
    value: 50550
    },
    {
    name: "Hastings",
    value: 25093
    },
    {
    name: "Kearney",
    value: 32174
    },
    {
    name: "La Vista",
    value: 17562
    },
    {
    name: "Lincoln",
    value: 268738
    },
    {
    name: "Norfolk",
    value: 24523
    },
    {
    name: "North Platte",
    value: 24534
    },
    {
    name: "Omaha",
    value: 434353
    },
    {
    name: "Papillion",
    value: 21921
    },
    {
    name: "Scottsbluff",
    value: 15023
    }]
},
{
name: "Nevada",
value: 2790136,
items: [{
    name: "Las Vegas",
    value: 603488
    },
    {
    name: "Henderson",
    value: 270811
    },
    {
    name: "Reno",
    value: 233294
    },
    {
    name: "Paradise",
    value: 230000
    },
    {
    name: "North Las Vegas",
    value: 226877
    },
    {
    name: "Sunrise Manor",
    value: 197000
    },
    {
    name: "Spring Valley",
    value: 188000
    },
    {
    name: "Enterprise",
    value: 130000
    },
    {
    name: "Sparks",
    value: 93282
    }]
},
{
name: "New Hampshire",
value: 1323459,
items: [{
    name: "Concord",
    value: 42419
    },
    {
    name: "Derry",
    value: 22000
    },
    {
    name: "Dover",
    value: 30510
    },
    {
    name: "Keene",
    value: 23419
    },
    {
    name: "Laconia",
    value: 16010
    },
    {
    name: "Manchester",
    value: 110378
    },
    {
    name: "Nashua",
    value: 87137
    },
    {
    name: "Portsmouth",
    value: 21440
    },
    {
    name: "Rochester",
    value: 29745
    }]
},
{
name: "New Jersey",
value: 8899339,
items: [{
    name: "Newark",
    value: 278427
    },
    {
    name: "Jersey City",
    value: 257342
    },
    {
    name: "Paterson",
    value: 145948
    },
    {
    name: "Elizabeth",
    value: 127558
    },
    {
    name: "Edison",
    value: 101450
    },
    {
    name: "Toms River",
    value: 89100
    },
    {
    name: "Clifton",
    value: 85390
    },
    {
    name: "Trenton",
    value: 84349
    },
    {
    name: "Camden",
    value: 76903
    },
    {
    name: "Brick Township",
    value: 75832
    }]
},
{
name: "New Mexico",
value: 2085287,
items: [{
    name: "Albuquerque",
    value: 556495
    },
    {
    name: "Las Cruces",
    value: 101324
    },
    {
    name: "Rio Rancho",
    value: 91956
    },
    {
    name: "Santa Fe",
    value: 69976
    },
    {
    name: "Roswell",
    value: 48611
    },
    {
    name: "Farmington",
    value: 45426
    },
    {
    name: "South Valley",
    value: 41700
    },
    {
    name: "Clovis",
    value: 39508
    },
    {
    name: "Hobbs",
    value: 36041
    },
    {
    name: "Alamogordo",
    value: 31368
    }]
},
{
name: "New York",
value: 19651127,
items: [    {
    name: "New York",
    value: 8405837
    },
    {
    name: "Buffalo",
    value: 258959
    },
    {
    name: "Rochester",
    value: 210358
    },
    {
    name: "Yonkers",
    value: 199766
    },
    {
    name: "Syracuse",
    value: 144669
    },
    {
    name: "Albany",
    value: 98424
    },
    {
    name: "New Rochelle",
    value: 79446
    },
    {
    name: "Cheektowaga",
    value: 74700
    },
    {
    name: "Mount Vernon",
    value: 68224
    },
    {
    name: "Schenectady",
    value: 65902
    }]
},
{
name: "North Carolina",
value: 9848060,
items: [{
    name: "Charlotte",
    value: 792862
    },
    {
    name: "Raleigh",
    value: 431746
    },
    {
    name: "Greensboro",
    value: 279639
    },
    {
    name: "Durham",
    value: 245475
    },
    {
    name: "Winston-Salem",
    value: 236441
    },
    {
    name: "Fayetteville",
    value: 204408
    },
    {
    name: "Cary",
    value: 151088
    },
    {
    name: "Wilmington",
    value: 112067
    },
    {
    name: "High Point",
    value: 107741
    }]
},
{
name: "North Dakota",
value: 723393
},
{
name: "Ohio",
value: 11570808,
items: [{
    name: "Columbus",
    value: 822553
    },
    {
    name: "Cleveland",
    value: 390113
    },
    {
    name: "Cincinnati",
    value: 297517
    },
    {
    name: "Toledo",
    value: 282313
    },
    {
    name: "Akron",
    value: 198100
    },
    {
    name: "Dayton",
    value: 143355
    },
    {
    name: "Parma",
    value: 80429
    },
    {
    name: "Canton",
    value: 72535
    },
    {
    name: "Youngstown",
    value: 65184
    },
    {
    name: "Lorain",
    value: 63710
    }]
},
{
name: "Oklahoma",
value: 3850568,
items: [{
    name: "Oklahoma City",
    value: 610613
    },
    {
    name: "Tulsa",
    value: 398121
    },
    {
    name: "Norman",
    value: 118197
    },
    {
    name: "Broken Arrow",
    value: 103500
    },
    {
    name: "Lawton",
    value: 97151
    },
    {
    name: "Edmond",
    value: 87004
    },
    {
    name: "Moore",
    value: 58414
    },
    {
    name: "Midwest City",
    value: 56756
    },
    {
    name: "Enid",
    value: 50725
    },
    {
    name: "Stillwater",
    value: 47186
    }]
},
{
name: "Oregon",
value: 3930065,
items: [{
    name: "Portland",
    value: 609456
    },
    {
    name: "Salem",
    value: 160614
    },
    {
    name: "Eugene",
    value: 159190
    },
    {
    name: "Gresham",
    value: 109397
    },
    {
    name: "Hillsboro",
    value: 97368
    },
    {
    name: "Beaverton",
    value: 93542
    },
    {
    name: "Bend",
    value: 81236
    },
    {
    name: "Medford",
    value: 77677
    },
    {
    name: "Springfield",
    value: 60177
    },
    {
    name: "Corvallis",
    value: 55298
    }]
},
{
name: "Pennsylvania",
value: 12773801,
items: [{
    name: "Philadelphia",
    value: 1553165
    },
    {
    name: "Pittsburgh",
    value: 305841
    },
    {
    name: "Allentown",
    value: 118577
    },
    {
    name: "Erie",
    value: 100671
    },
    {
    name: "Reading",
    value: 87893
    },
    {
    name: "Scranton",
    value: 75806
    },
    {
    name: "Bethlehem",
    value: 75018
    },
    {
    name: "Lancaster",
    value: 59325
    },
    {
    name: "Levittown",
    value: 52700
    },
    {
    name: "Harrisburg",
    value: 49188
    }]
},
{
name: "Rhode Island",
value: 1051511,
items: [{
    name: "Providence",
    value: 177994
    },
    {
    name: "Warwick",
    value: 81971
    },
    {
    name: "Cranston",
    value: 80566
    },
    {
    name: "Pawtucket",
    value: 71172
    }]
},
{
name: "South Carolina",
value: 4774839,
items: [{
    name: "Columbia",
    value: 133358
    },
    {
    name: "Charleston",
    value: 127999
    },
    {
    name: "North Charleston",
    value: 104054
    },
    {
    name: "Mount Pleasant",
    value: 74885
    },
    {
    name: "Rock Hill",
    value: 69103
    },
    {
    name: "Greenville",
    value: 61397
    },
    {
    name: "Summerville",
    value: 46074
    },
    {
    name: "Sumter",
    value: 41190
    },
    {
    name: "Goose Creek",
    value: 39823
    },
    {
    name: "Hilton Head Island",
    value: 39412
    }]
},
{
name: "South Dakota",
value: 844877
},
{
name: "Tennessee",
value: 6495978,
items: [{
    name: "Memphis",
    value: 653450
    },
    {
    name: "Nashville",
    value: 634464
    },
    {
    name: "Knoxville",
    value: 183270
    },
    {
    name: "Chattanooga",
    value: 173366
    },
    {
    name: "Clarksville",
    value: 142357
    },
    {
    name: "Murfreesboro",
    value: 117044
    },
    {
    name: "Franklin",
    value: 68886
    },
    {
    name: "Jackson",
    value: 67685
    },
    {
    name: "Johnson City",
    value: 65123
    },
    {
    name: "Bartlett",
    value: 58226
    }]
},
{
name: "Texas",
value: 26448193,
items: [{
    name: "Houston",
    value: 2195914
    },
    {
    name: "San Antonio",
    value: 1409019
    },
    {
    name: "Dallas",
    value: 1257676
    },
    {
    name: "Austin",
    value: 885400
    },
    {
    name: "Fort Worth",
    value: 792727
    },
    {
    name: "El Paso",
    value: 674433
    },
    {
    name: "Arlington",
    value: 379577
    },
    {
    name: "Corpus Christi",
    value: 316381
    },
    {
    name: "Plano",
    value: 274409
    }]
},
{
name: "Utah",
value: 2900872,
items: [{
    name: "Salt Lake City",
    value: 191180
    },
    {
    name: "West Valley City",
    value: 133579
    },
    {
    name: "Provo",
    value: 116288
    },
    {
    name: "West Jordan",
    value: 110077
    },
    {
    name: "Orem",
    value: 91648
    },
    {
    name: "Sandy",
    value: 90231
    },
    {
    name: "Ogden",
    value: 84249
    },
    {
    name: "St. George",
    value: 76817
    },
    {
    name: "Layton",
    value: 70790
    }]
},
{
name: "Vermont",
value: 626630,
items: [{
    name: "Burlington",
    value: 42284
    },
    {
    name: "Montpelier",
    value: 7755
    },
    {
    name: "Rutland",
    value: 16126
    },
    {
    name: "South Burlington",
    value: 18612
    }]
},
{
name: "Virginia",
value: 8260405,
items: [{
    name: "Virginia Beach",
    value: 448479
    },
    {
    name: "Norfolk",
    value: 246139
    },
    {
    name: "Chesapeake",
    value: 230571
    },
    {
    name: "Arlington",
    value: 224906
    },
    {
    name: "Richmond",
    value: 214114
    },
    {
    name: "Newport News",
    value: 182020
    },
    {
    name: "Alexandria",
    value: 148892
    },
    {
    name: "Hampton",
    value: 136699
    },
    {
    name: "Roanoke",
    value: 98465
    },
    {
    name: "Portsmouth",
    value: 96205
    }]
},
{
name: "Washington",
value: 6971406,
items: [{
    name: "Seattle",
    value: 652405
    },
    {
    name: "Spokane",
    value: 210721
    },
    {
    name: "Tacoma",
    value: 203446
    },
    {
    name: "Vancouver",
    value: 167405
    },
    {
    name: "Bellevue",
    value: 133992
    },
    {
    name: "Kent",
    value: 124435
    },
    {
    name: "Everett",
    value: 105370
    },
    {
    name: "Renton",
    value: 97003
    },
    {
    name: "Yakima",
    value: 93257
    },
    {
    name: "Federal Way",
    value: 92734
    },
    {
    name: "Spokane Valley",
    value: 91113
    }]
},
{
name: "West Virginia",
value: 1854304,
items: [{
    name: "Beckley  17607
    },
    {
    name: "Charleston",
    value: 50821
    },
    {
    name: "Clarksburg",
    value: 16360
    },
    {
    name: "Fairmont",
    value: 18815
    },
    {
    name: "Huntington",
    value: 49177
    },
    {
    name: "Martinsburg",
    value: 17668
    },
    {
    name: "Morgantown",
    value: 30666
    },
    {
    name: "Parkersburg",
    value: 31186
    },
    {
    name: "Weirton",
    value: 19525
    },
    {
    name: "Wheeling",
    value: 28009
    }]
},
{
name: "Wisconsin",
value: 5742713,
items: [{
    name: "Milwaukee",
    value: 599164
    },
    {
    name: "Madison",
    value: 243344
    },
    {
    name: "Green Bay",
    value: 104779
    },
    {
    name: "Kenosha",
    value: 99889
    },
    {
    name: "Racine",
    value: 78199
    },
    {
    name: "Appleton",
    value: 73596
    },
    {
    name: "Waukesha",
    value: 71016
    },
    {
    name: "Eau Claire",
    value: 67545
    },
    {
    name: "Oshkosh",
    value: 66778
    },
    {
    name: "Janesville",
    value: 63820
    },
    {
    name: "West Allis",
    value: 60697
    }]
},
{
name: "Wyoming",
value: 582658
}
